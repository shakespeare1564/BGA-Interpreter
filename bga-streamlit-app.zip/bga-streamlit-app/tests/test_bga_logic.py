import unittest
from bga_logic import (
    BGAInput, albumin_corrected_ag, analyse_bga, arterial_oxygen_content,
    calculate_anion_gap, osmolal_gap, pf_ratio, urine_anion_gap,
    winter_expected_pco2,
)


class TestBGALogic(unittest.TestCase):
    def test_anion_gap(self):
        self.assertAlmostEqual(calculate_anion_gap(140, 100, 14), 26.0)

    def test_albumin_correction(self):
        self.assertAlmostEqual(albumin_corrected_ag(26, 30), 28.5)

    def test_winter_formula(self):
        center, low, high = winter_expected_pco2(14)
        self.assertEqual((center, low, high), (29.0, 27.0, 31.0))

    def test_article_case(self):
        data = BGAInput(
            sample_type="arteriell", ph=7.31, pco2=55, hco3=29,
            sodium=135, chloride=80, albumin=30, lactate=7.9,
        )
        result = analyse_bga(data)
        self.assertFalse(result["errors"])
        self.assertAlmostEqual(result["anion_gap"], 26.0)
        self.assertAlmostEqual(result["corrected_anion_gap"], 28.5)
        self.assertIn("HAGMA", result["ag_interpretation"])
        self.assertIsNone(result["delta_ratio"])
        self.assertIn("metabolische Alkalose", result["delta_interpretation"])

    def test_nagma(self):
        data = BGAInput(
            sample_type="arteriell", ph=7.25, pco2=28, hco3=12,
            sodium=140, chloride=116, albumin=40,
        )
        result = analyse_bga(data)
        self.assertIn("NAGMA", result["ag_interpretation"])

    def test_cao2(self):
        self.assertAlmostEqual(arterial_oxygen_content(15, 98, 100), 20.0, places=1)

    def test_pf_ratio(self):
        self.assertAlmostEqual(pf_ratio(80, 40), 200.0)

    def test_osmolal_gap(self):
        self.assertAlmostEqual(osmolal_gap(300, 140, 5, 5), 10.0)

    def test_urine_anion_gap(self):
        self.assertAlmostEqual(urine_anion_gap(20, 20, 80), -40.0)


if __name__ == "__main__":
    unittest.main()
